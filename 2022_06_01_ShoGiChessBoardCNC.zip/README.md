# 2020_09_27_ShoGiCNCProductionBoard
This project was an attempt to do a ShoGi Game with CNC by using some holder board.
